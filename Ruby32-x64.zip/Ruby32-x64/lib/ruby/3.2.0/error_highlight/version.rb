module ErrorHighlight
  VERSION = "0.5.1"
end
