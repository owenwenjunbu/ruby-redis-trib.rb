# frozen_string_literal: true

module Bundler; end
require_relative "vendor/uri/lib/uri"
